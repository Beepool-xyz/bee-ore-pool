#!/usr/bin/env bash

# 切换到脚本所在目录
cd $(dirname "$0")

# 如果没有设置 CUSTOM_URL，使用默认地址
CUSTOM_URL=${CUSTOM_URL:-"http://orepool.xyz:8080"}

# 构建配置文件内容
conf=$(printf 'WALLET_ADDRESS="%s"\nSERVER_URL="%s"\nEXTRA="%s"\n' \
    "$CUSTOM_TEMPLATE" "$CUSTOM_URL" "$CUSTOM_USER_CONFIG")

# 写入到指定的配置文件中
echo "$conf" > "$CUSTOM_CONFIG_FILENAME"
