
cd `dirname $0`

[[ "$CUSTOM_URL" = "" ]] && echo "Using default address" && CUSTOM_URL="public&stake"


conf=""
conf+="WALLET_ADDRESS=\"$CUSTOM_TEMPLATE\""$'\n'
conf+="SERVER_URL=\"$CUSTOM_URL\""$'\n'


echo "$conf" > $CUSTOM_CONFIG_FILENAME