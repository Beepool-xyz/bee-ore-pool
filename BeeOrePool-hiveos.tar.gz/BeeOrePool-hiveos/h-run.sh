#!/bin/bash

source h-manifest.conf
source $CUSTOM_CONFIG_FILENAME

# 修改可执行文件权限
sudo chmod a+x ./mine

cpuNUM=$(echo "$(lscpu | grep '^CPU(s):' | awk '{print $2}') * 1" | bc | awk '{print int($1)}')

COMMAND="./mine --url='$SERVER_URL'--core=$cpuNUM --address='$WALLET_ADDRESS' 2>&1 | tee /var/log/ore.log"

# 无限循环，除非明确退出
while true; do
    # 执行命令
    echo "Starting command: $COMMAND"
    eval $COMMAND

    # 打印退出状态
    EXIT_STATUS=$?
    echo "Command exited with status $EXIT_STATUS"

    # 休眠几秒后重启（可选）
    sleep 10
done
