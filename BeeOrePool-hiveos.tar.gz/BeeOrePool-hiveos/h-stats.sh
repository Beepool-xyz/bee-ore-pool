#!/bin/bash

# 定义日志文件路径
log_name="/var/log/ore.log"


khs=$(tail "$log_name" | grep power: | tail -n 1 | sed -n 's/.*power: \([0-9]*\)\,.*/\1/p')   

echo "khs: $khs"