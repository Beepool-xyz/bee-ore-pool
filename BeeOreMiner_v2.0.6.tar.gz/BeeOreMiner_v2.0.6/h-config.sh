#!/usr/bin/env bash

# 判断是否包含 '.'
if [[ "$CUSTOM_TEMPLATE" == *"."* ]]; then
    IFS='.' read -r WALLET_ADDRESS MINER_NAME <<< "$CUSTOM_TEMPLATE"
else
    # 如果没有 '.', 只解析 WAL，并为 WORKER_NAME 设置默认值
    WALLET_ADDRESS="$CUSTOM_TEMPLATE"
    MINER_NAME="miner"
fi

# 生成最终配置
conf=$(printf 'WALLET_ADDRESS="%s"\nMINER_NAME="%s"\nSERVER_URL="%s"\nEXTRA="%s"\n' \
    "$WALLET_ADDRESS" "$MINER_NAME" "$CUSTOM_URL" "$CUSTOM_USER_CONFIG")

echo "$conf" > "$CUSTOM_CONFIG_FILENAME"
